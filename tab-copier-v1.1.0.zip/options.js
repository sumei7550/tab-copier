document.addEventListener('DOMContentLoaded', async () => {
  const $ = (id) => document.getElementById(id);
  const t = (key) => TabCopierI18n.t(key);
  const entitlement = await TabCopierFeatureFlags.load();
  const defaults = { format: 'markdown', allWindows: false, excludePinned: false, removeDuplicates: true, removeTracking: true };
  const settings = { ...defaults, ...(await chrome.storage.local.get(defaults)) };
  document.title = t('settingsTitle');
  const labels = { markdown: 'formatMarkdown', text: 'formatText', urls: 'formatUrls' };
  $('pageTitle').textContent = t('settingsTitle'); $('pageIntro').textContent = t('settingsIntro'); $('copyDefaultsHeading').textContent = t('copyDefaults'); $('defaultFormatLabel').textContent = t('defaultFormat'); $('defaultAllWindowsLabel').textContent = t('allWindows'); $('excludePinnedLabel').textContent = t('excludePinned'); $('removeDuplicatesLabel').textContent = t('removeDuplicates'); $('removeTrackingLabel').textContent = t('removeTracking'); $('shortcutHeading').textContent = t('keyboardShortcut'); $('shortcutText').textContent = t('shortcutDescription'); $('shortcutLink').textContent = t('manageShortcuts');
  Object.entries(labels).forEach(([value, key]) => { $('defaultFormat').querySelector(`[value="${value}"]`).textContent = t(key); });
  $('defaultFormat').value = ['markdown', 'text', 'urls'].includes(settings.format) ? settings.format : 'text';
  ['defaultAllWindows', 'excludePinned', 'removeDuplicates', 'removeTracking'].forEach((id) => { $(id).checked = settings[id === 'defaultAllWindows' ? 'allWindows' : id]; });
  $('defaultAllWindows').disabled = !entitlement.capabilities.allWindows;
  $('removeDuplicates').disabled = !entitlement.capabilities.deduplicate;
  if (!entitlement.capabilities.allWindows) $('defaultAllWindows').checked = false;
  if (!entitlement.capabilities.deduplicate) $('removeDuplicates').checked = false;
  const save = async () => { const next = { format: $('defaultFormat').value, allWindows: entitlement.capabilities.allWindows && $('defaultAllWindows').checked, excludePinned: $('excludePinned').checked, removeDuplicates: entitlement.capabilities.deduplicate && $('removeDuplicates').checked, removeTracking: $('removeTracking').checked }; await chrome.storage.local.set(next); $('savedMessage').textContent = t('saved'); setTimeout(() => { $('savedMessage').textContent = ''; }, 1800); };
  document.querySelectorAll('input, select').forEach((element) => element.addEventListener('change', save));
});
